%CLS - use to clear, reset priority, and show the cursor, and close figs.

clear Screen;
Priority(0);
ShowCursor;
close all;