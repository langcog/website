% From Psychtoolbox (Brainard & Pelli) - included to avoid dependencies

function i = randint(n);

i=ceil(n*rand);